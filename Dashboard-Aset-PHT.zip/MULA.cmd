@echo off
cd /d "%~dp0"
start "" "http://127.0.0.1:4180"
"C:\Users\HP\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" server.py
pause
