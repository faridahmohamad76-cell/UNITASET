from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import sqlite3,json,re,hashlib,hmac,secrets,time,collections,threading
ROOT=Path(__file__).resolve().parent
SESSIONS={};ATTEMPTS={};LOCK=threading.Lock()
def key(x):return re.sub(r'[^A-Z0-9]','',re.sub(r'^(DR\.?|PROF\.?)\s+','',str(x).strip().upper()))
def connect():
 db=sqlite3.connect(ROOT/'aset.db');db.row_factory=sqlite3.Row;return db
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def reply(self,status,data,cookie=None):
  payload=json.dumps(data,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
  if cookie:self.send_header('Set-Cookie',cookie)
  self.end_headers();self.wfile.write(payload)
 def user(self):
  cookie=self.headers.get('Cookie','');m=re.search(r'(?:^|;\s*)pht_session=([a-f0-9]+)',cookie)
  if not m:return None
  with LOCK:
   s=SESSIONS.get(m[1]);return s[0] if s and s[1]>time.time() else None
 def do_GET(self):
  if self.path in ('/','/index.html'):
   self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Frame-Options','DENY');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write((ROOT/'index.html').read_bytes());return
  if self.path=='/api/data':
   user=self.user()
   if not user:self.reply(401,{'error':'Sila log masuk.'});return
   with connect() as db:
    assets=[dict(r) for r in db.execute('SELECT * FROM assets')];rooms=[dict(r) for r in db.execute('SELECT * FROM rooms')];staff=[dict(r) for r in db.execute('SELECT name,key,role,unit FROM staff')]
   self.reply(200,dict(user=user,assets=assets,rooms=rooms,staff=staff));return
  self.reply(404,{'error':'Tidak ditemui.'})
 def do_POST(self):
  origin=self.headers.get('Origin')
  if origin and origin!='http://'+self.headers.get('Host',''):self.reply(403,{'error':'Permintaan tidak dibenarkan.'});return
  if self.path=='/api/logout':
   m=re.search(r'pht_session=([a-f0-9]+)',self.headers.get('Cookie',''))
   if m:
    with LOCK:SESSIONS.pop(m[1],None)
   self.reply(200,{'ok':True},'pht_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return
  if self.path!='/api/login':self.reply(404,{'error':'Tidak ditemui.'});return
  try:
   length=int(self.headers.get('Content-Length',0))
   if length>4096:raise ValueError()
   data=json.loads(self.rfile.read(length));name=key(data.get('name',''));ic=re.sub(r'\D','',str(data.get('password','')))
  except:self.reply(400,{'error':'Maklumat tidak sah.'});return
  ip=self.client_address[0]
  with LOCK:
   attempts=[t for t in ATTEMPTS.get(ip,[]) if t>time.time()-300];ATTEMPTS[ip]=attempts
   if len(attempts)>=10:self.reply(429,{'error':'Terlalu banyak cubaan. Cuba semula selepas 5 minit.'});return
   attempts.append(time.time())
  with connect() as db:row=db.execute('SELECT * FROM staff WHERE key=?',(name,)).fetchone()
  salt=bytes.fromhex(row['salt']) if row else bytes(16)
  digest=hashlib.scrypt(ic.encode(),salt=salt,n=16384,r=8,p=1).hex()
  if not row or len(ic)!=12 or not hmac.compare_digest(digest,row['hash']):self.reply(401,{'error':'Nama penuh atau nombor IC tidak sepadan.'});return
  user={k:row[k] for k in ('name','key','role','unit')};token=secrets.token_hex(32)
  with LOCK:SESSIONS[token]=(user,time.time()+3600);ATTEMPTS.pop(ip,None)
  self.reply(200,{'ok':True},f'pht_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=3600')
if __name__=='__main__':
 print('Dashboard PHT: http://127.0.0.1:4180',flush=True)
 ThreadingHTTPServer(('127.0.0.1',4180),Handler).serve_forever()
